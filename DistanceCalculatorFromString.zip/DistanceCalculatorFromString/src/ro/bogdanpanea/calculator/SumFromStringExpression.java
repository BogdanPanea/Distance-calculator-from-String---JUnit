package ro.bogdanpanea.calculator;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SumFromStringExpression {

    private static Logger LOGGER = Logger.getLogger( Main.class.getName() );
    private String expression;
    private List<Operand> operandsList = new ArrayList<>();
    private Operand operand;


    private static final Map<String, Double> unitsConstant;

    static {

        unitsConstant = new HashMap<String, Double>();
        unitsConstant.put( "mm", 0.001 );
        unitsConstant.put( "cm", 0.01 );
        unitsConstant.put( "dm", 0.1 );
        unitsConstant.put( "m", 1.0 );
        unitsConstant.put( "km", 1000.0 );
    }


    public SumFromStringExpression(String expression) {

        try {
            if (!expression.equals( "" )) {
                this.expression = expression;
            } else {

                throw new SumStringFromExpressionException( "Expresia trebuie sa nu fie vida !", "Expresie vida." );
            }
        } catch (SumStringFromExpressionException e) {

            LOGGER.log( Level.SEVERE, e.getMessage() );
        }
    }

    public void generateOperandsList() {


        String operand = "";
        Integer operator = 1;

        for (int i = 0; i < expression.length(); i++) {

            switch (expression.charAt( i )) {
                case '+':
                    Integer number1 = operator * Integer.parseInt( operand.replaceAll( "\\D+", "" ) );
                    String string1 = operand.replaceAll( "[^A-Za-z]+", "" );
                    operandsList.add( new Operand( number1, string1, unitsConstant.get( string1 ) ) );
                    operator = 1;
                    operand = "";
                    break;
                case '-':
                    Integer number2 = operator * Integer.parseInt( operand.replaceAll( "\\D+", "" ) );
                    String string2 = operand.replaceAll( "[^A-Za-z]+", "" );
                    operandsList.add( new Operand( number2, string2, unitsConstant.get( string2 ) ) );
                    operator = -1;
                    operand = "";
                    break;
                default:
                    operand = operand + expression.charAt( i );


            }
        }

        Integer number1 = operator * Integer.parseInt( operand.replaceAll( "\\D+", "" ) );
        String string1 = operand.replaceAll( "[^A-Za-z]+", "" );
        operandsList.add( new Operand( number1, string1, unitsConstant.get( string1 ) ) );
    }

    public void listOperands() {
        for (Operand operand : operandsList) {
            LOGGER.info( operand.toString() );
        }
    }

    public void sortListOperandsByUnit() {

        Collections.sort( operandsList, new UnitsConstantComparator() );
    }

    public String returnDistanceInLowestUnit() {

        double totalDistance = 0;

        sortListOperandsByUnit();

        Double curentUnitConstan = operandsList.get( 0 ).getUnitConstant();
        String unit = operandsList.get( 0 ).getUnit();

        for (Operand operand : operandsList) {
            totalDistance = totalDistance + (double) operand.getDistance() * (operand.getUnitConstant() / curentUnitConstan);

        }

        return (int) totalDistance + " " + unit;
    }

    public String returnDistanceInCustomUnit(String unit) {

        String curentUnit;
        Integer curentValue;
        double newUnitValue;

        try {

            if (checkUnits( unit )) {
                String result = returnDistanceInLowestUnit();
                curentUnit = result.replaceAll( "[^A-Za-z]+", "" );
                curentValue = Integer.parseInt( result.replaceAll( "[^\\d-]", "" ) );

                if (curentUnit.equals( unit )) {
                    return curentValue + " " + curentUnit;
                } else {
                    Double factor = unitsConstant.get( curentUnit ) / unitsConstant.get( unit );
                    newUnitValue = factor * (double) curentValue;
                    System.out.println( factor );
                }
                return (int)newUnitValue + " " + unit;
            } else {

                throw new SumStringFromExpressionException( "Unitate de masura invalida ! Doar mm, cm , dm , m si km sunt persmisi.", "Unitate de masura incorecta" );
            }
        } catch (SumStringFromExpressionException e) {

            LOGGER.log( Level.SEVERE, e.getMessage() );
            return null;
        }
    }

    public static boolean checkUnits(String unit) {
        if (unitsConstant.containsKey( unit )) {

            return true;
        } else {

            return false;
        }
    }
}
